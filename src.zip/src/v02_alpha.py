"""v02 alpha: route-aware guided-choice baseline.

New naming after the refactor:
    v02_alpha = old v02_beta

Final-inference compliant:
    one primary LLM only, no S5 embedder, no RAG, no reranker.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.version_runner import add_common_args, run_v02_alpha


def main() -> None:
    parser = argparse.ArgumentParser(description="Run v02_alpha route-aware guided choice")
    add_common_args(
        parser,
        default_output="data/submissions/submission_v02_alpha.csv",
        default_trace="data/traces/trace_v02_alpha.jsonl",
    )
    args = parser.parse_args()

    run_v02_alpha(
        input_path=args.input,
        output_path=args.output,
        trace_output=args.trace_output,
        model_id=args.model_id,
        limit=args.limit,
        safe_mode=args.safe_mode,
        gpu_memory_utilization=args.gpu_memory_utilization,
        max_model_len=args.max_model_len,
        max_num_seqs=args.max_num_seqs,
    )


if __name__ == "__main__":
    main()
